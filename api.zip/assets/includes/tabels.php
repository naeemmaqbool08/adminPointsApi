<?php

define('T_USERS', 'users');
define('T_REWARD_LINKS', 'reward_link');

?>

<?php

$sql_db_host = "localhost";
$sql_db_user = "root";
$sql_db_pass = "";
$sql_db_name = "admin_points_api";


$site_url = "http://example.com";


$pt_server_key = 'cd610c33f5c8bb77f74928d94f89af8e';

?>